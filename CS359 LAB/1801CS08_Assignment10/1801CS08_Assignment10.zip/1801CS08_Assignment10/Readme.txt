Name: Ammaar Ahmad
Roll No: 1801CS08


Problem 1

Server:
Compilation:  gcc Q1_server.c -o Q1s
Execution Syntax: ./Q1s

Client:
Compilation:  gcc Q1_client.c -o Q1c
Execution Syntax: ./Q1c

Output: 

Client:
Connected to Server.
Hello Ammaar
HELLO AMMAAR

Server:
Binding successfull.
hello ammaar





Problem 2

Server:
Compilation:  gcc Q2_server.c -o Q1s
Execution Syntax: ./Q2s

Client:
Compilation:  gcc Q2_client.c -o Q1c
Execution Syntax: ./Q2c

Output: 

Client:
Connected to Server.
Hello Madam
madaM olleH

Server:
Binding successfull.
Hello Madam





Problem 3

Server:
Compilation:  gcc Q3_server.c -o Q1s
Execution Syntax: ./Q3s

Client:
Compilation:  gcc Q3_client.c -o Q1c
Execution Syntax: ./Q3c


Output: 

Client:
Connected to Server.
5
1 2 3 4 5

Server:
Binding successfull.
1 2 3 4 5 

