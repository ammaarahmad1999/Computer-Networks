NAME : AMMAAR AHMAD
ROLL NO : 1801CS08

1)create a text file and write some data in it, start with HELLO and end with END.

2)open a terminal and start the server 
compile : gcc word_server.c -o server
execute : ./server

3)open another terminal and start the client program.
compile : gcc word_client.c -o 
execute : ./client

4)a new file will be created with the name newfile.txt , it will have the same contents as the filename.txt file.
each step of the client server data transfer is printed in the terminals.
