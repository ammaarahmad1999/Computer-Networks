NAME : AMMAAR AHMAD
ROLL NO : 1801CS08

For TCP
1)create a text file and write some data in it

2)open a terminal and start the server 
compile : gcc TCP_server.c -o server
execute : ./server

3)open another terminal and start the client program.
compile : gcc TCP_client.c -o 
execute : ./client
Enter the filename //To read by client 
file.txt
Enter the another filename in which data is copied //To write by server
newfile.txt


For UDP

1)create a text file and write some data in it

2)open a terminal and start the server 
compile : gcc UDP_server.c -o server
execute : ./server

3)open another terminal and start the client program.
compile : gcc UDP_client.c -o 
execute : ./client
Enter the filename //To read by client 
file.txt
Enter the another filename in which data is copied //To write by server
newfile.txt


