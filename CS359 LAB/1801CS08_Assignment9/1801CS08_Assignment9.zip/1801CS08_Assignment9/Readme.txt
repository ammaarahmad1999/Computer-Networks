Name: Ammaar Ahmad
Roll No: 1801CS08


Problem 1

Server:
Compilation:  g++ Q1_server.c -o Q1s
Execution Syntax: ./Q1s

Client:
Compilation:  g++ Q1_client.c -o Q1c
Execution Syntax: ./Q1c

Output: 

Client:
Connected to Server.
Message successfully sent.

Server:
Binding successfull.
Number of vowels are: 13




Problem 2

Server:
Compilation:  g++ Q2_server.c -o Q1s
Execution Syntax: ./Q2s

Client:
Compilation:  g++ Q2_client.c -o Q1c
Execution Syntax: ./Q2c

Output: 

Client:
Connected to Server.
madam
Message successfully sent.

Server:
Binding successfull.
madam
It is a palindrome.



Problem 3

Server:
Compilation:  g++ Q3_server.c -o Q1s
Execution Syntax: ./Q3s

Client:
Compilation:  g++ Q3_client.c -o Q1c
Execution Syntax: ./Q3c


Output: 

Client:
Connected to Server.
5
1 2 3 4 5
Sum of elements = 15

Server:
Binding successfull.
1 2 3 4 5 

